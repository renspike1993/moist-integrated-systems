import os, zipfile, pathlib, shutil

# Project structure in memory
project = {
    "intramurals/manage.py": """#!/usr/bin/env python
import os, sys

def main():
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'intramurals.settings')
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError("Couldn't import Django.") from exc
    execute_from_command_line(sys.argv)

if __name__ == '__main__':
    main()
""",

    "intramurals/intramurals/__init__.py": "",
    "intramurals/intramurals/asgi.py": """import os
from django.core.asgi import get_asgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'intramurals.settings')
application = get_asgi_application()
""",
    "intramurals/intramurals/wsgi.py": """import os
from django.core.wsgi import get_wsgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'intramurals.settings')
application = get_wsgi_application()
""",
    "intramurals/intramurals/urls.py": """from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path("admin/", admin.site.urls),
    path("", include("core.urls")),
]
""",
    "intramurals/intramurals/settings.py": """from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

SECRET_KEY = 'your-secret-key'
DEBUG = True
ALLOWED_HOSTS = []

INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "core",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

ROOT_URLCONF = "intramurals.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [BASE_DIR / "templates"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]

WSGI_APPLICATION = "intramurals.wsgi.application"

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.sqlite3",
        "NAME": BASE_DIR / "db.sqlite3",
    }
}

AUTH_PASSWORD_VALIDATORS = []
LANGUAGE_CODE = "en-us"
TIME_ZONE = "UTC"
USE_I18N = True
USE_TZ = True

STATIC_URL = "static/"
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

AUTH_USER_MODEL = "core.User"
""",
    "intramurals/core/__init__.py": "",
    "intramurals/core/apps.py": """from django.apps import AppConfig

class CoreConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'core'
""",
    "intramurals/core/models.py": """from django.db import models
from django.contrib.auth.models import AbstractUser

class User(AbstractUser):
    ROLE_CHOICES = [
        ("game_manager", "Game Manager"),
        ("admin", "Admin"),
        ("viewer", "Viewer"),
    ]
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default="viewer")

    def __str__(self):
        return self.username

class TeamCategory(models.Model):
    name = models.CharField(max_length=100)
    def __str__(self):
        return self.name

class Team(models.Model):
    category = models.ForeignKey(TeamCategory, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    def __str__(self):
        return self.name

class GameCategory(models.Model):
    name = models.CharField(max_length=100)
    manager = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL)
    def __str__(self):
        return self.name

class Game(models.Model):
    category = models.ForeignKey(GameCategory, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    description = models.TextField(null=True, blank=True)
    def __str__(self):
        return self.name

class Match(models.Model):
    team = models.ForeignKey(Team, on_delete=models.CASCADE)
    game = models.ForeignKey(Game, on_delete=models.CASCADE)
    live_link = models.URLField(null=True, blank=True)
    started_at = models.DateTimeField()
    ended_at = models.DateTimeField()
    def __str__(self):
        return f"{self.team} vs {self.game}"

class Result(models.Model):
    RANK_CHOICES = [("1st", "1st"), ("2nd", "2nd"), ("3rd", "3rd")]
    match = models.ForeignKey(Match, on_delete=models.CASCADE)
    rank = models.CharField(max_length=10, choices=RANK_CHOICES)
    submitted_by = models.ForeignKey(User, on_delete=models.CASCADE)
    def __str__(self):
        return f"{self.match} - {self.rank}"
""",
    "intramurals/core/views.py": """from django.shortcuts import render
from .models import Team, Game

def home(request):
    teams = Team.objects.all()
    games = Game.objects.all()
    return render(request, "core/home.html", {"teams": teams, "games": games})
""",
    "intramurals/core/urls.py": """from django.urls import path
from . import views

urlpatterns = [
    path("", views.home, name="home"),
]
""",
    "intramurals/core/admin.py": """from django.contrib import admin
from .models import User, TeamCategory, Team, GameCategory, Game, Match, Result

admin.site.register(User)
admin.site.register(TeamCategory)
admin.site.register(Team)
admin.site.register(GameCategory)
admin.site.register(Game)
admin.site.register(Match)
admin.site.register(Result)
""",
    "intramurals/templates/core/base.html": """<!DOCTYPE html>
<html>
<head>
    <title>Intramurals</title>
</head>
<body>
    <h1>Intramurals System</h1>
    {% block content %}{% endblock %}
</body>
</html>
""",
    "intramurals/templates/core/home.html": """{% extends "core/base.html" %}
{% block content %}
<h2>Teams</h2>
<ul>
    {% for team in teams %}
    <li>{{ team.name }}</li>
    {% endfor %}
</ul>

<h2>Games</h2>
<ul>
    {% for game in games %}
    <li>{{ game.name }}</li>
    {% endfor %}
</ul>
{% endblock %}
"""
}

# Write project files
for path, content in project.items():
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)

# Zip the project
zip_filename = "intramurals_project.zip"
with zipfile.ZipFile(zip_filename, "w", zipfile.ZIP_DEFLATED) as z:
    for path in project:
        z.write(path)

print(f"Created {zip_filename} with {len(project)} files.")
