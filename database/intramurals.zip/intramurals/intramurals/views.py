from django.shortcuts import render, redirect
from .forms import MatchForm


def create_match(request):
    if request.method == "POST":
        form = MatchForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("match_list")  # your URL name
    else:
        form = MatchForm()
    return render(request, "matches/match_form.html", {"form": form})
