from django.db import models
from django.contrib.auth.models import AbstractUser

class User(AbstractUser):
    ROLE_CHOICES = [
        ("game_manager", "Game Manager"),
        ("admin", "Admin"),
        ("viewer", "Viewer"),
    ]
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default="viewer")

    def __str__(self):
        return self.username

class TeamCategory(models.Model):
    name = models.CharField(max_length=100)
    def __str__(self):
        return self.name

class Team(models.Model):
    category = models.ForeignKey(TeamCategory, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    def __str__(self):
        return self.name

class GameCategory(models.Model):
    name = models.CharField(max_length=100)
    manager = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL)
    def __str__(self):
        return self.name

class Game(models.Model):
    category = models.ForeignKey(GameCategory, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    description = models.TextField(null=True, blank=True)
    def __str__(self):
        return self.name

class Match(models.Model):
    team = models.ForeignKey(Team, on_delete=models.CASCADE)
    game = models.ForeignKey(Game, on_delete=models.CASCADE)
    live_link = models.URLField(null=True, blank=True)
    started_at = models.DateTimeField()
    ended_at = models.DateTimeField()
    def __str__(self):
        return f"{self.team} vs {self.game}"

class Result(models.Model):
    RANK_CHOICES = [("1st", "1st"), ("2nd", "2nd"), ("3rd", "3rd")]
    match = models.ForeignKey(Match, on_delete=models.CASCADE)
    rank = models.CharField(max_length=10, choices=RANK_CHOICES)
    submitted_by = models.ForeignKey(User, on_delete=models.CASCADE)
    def __str__(self):
        return f"{self.match} - {self.rank}"
