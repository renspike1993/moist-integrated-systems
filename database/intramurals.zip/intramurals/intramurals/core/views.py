from django.shortcuts import render
from .models import Team, Game

def home(request):
    teams = Team.objects.all()
    games = Game.objects.all()
    return render(request, "core/home.html", {"teams": teams, "games": games})
