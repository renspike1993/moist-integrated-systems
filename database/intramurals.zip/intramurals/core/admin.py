from django.contrib import admin
from .models import *


@admin.register(User)
class UserAdmin(admin.ModelAdmin):
    list_display = ('id', 'username', 'role')
    list_filter = ('role',)


@admin.register(TeamCategory)
class TeamCategoryAdmin(admin.ModelAdmin):
    list_display = ('id', 'team_category_name')


@admin.register(Team)
class TeamAdmin(admin.ModelAdmin):
    list_display = ('id', 'team_name', 'category')


@admin.register(GameCategory)
class GameCategoryAdmin(admin.ModelAdmin):
    list_display = ('id', 'game_category_name', 'game_manager')


@admin.register(Game)
class GameAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'category', 'description')


@admin.register(Match)
class MatchAdmin(admin.ModelAdmin):
    list_display = ('id', 'team', 'game', 'live_link', 'started_at', 'ended_at')


@admin.register(Result)
class ResultAdmin(admin.ModelAdmin):
    list_display = ('id', 'match', 'rank', 'submitted_by')


@admin.register(FieldVisibility)
class FieldVisibilityAdmin(admin.ModelAdmin):
    list_display = ('model_name', 'field_name', 'is_visible')
    list_editable = ('is_visible',)
