from django.db import models
from django.contrib.auth.models import AbstractUser


class User(AbstractUser):
    ROLE_CHOICES = [
        ('game_manager', 'Game Manager'),
        ('admin', 'Admin'),
        ('viewer', 'Viewer'),
    ]
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='viewer')

    def __str__(self):
        return self.username


class TeamCategory(models.Model):
    team_category_name = models.CharField(max_length=100)

    def __str__(self):
        return self.team_category_name


class Team(models.Model):
    category = models.ForeignKey(TeamCategory, on_delete=models.CASCADE, related_name="teams")
    team_name = models.CharField(max_length=100)

    def __str__(self):
        return self.team_name


class GameCategory(models.Model):
    game_category_name = models.CharField(max_length=100)
    game_manager = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL)

    def __str__(self):
        return self.game_category_name


class Game(models.Model):
    category = models.ForeignKey(GameCategory, on_delete=models.CASCADE, related_name="games")
    name = models.CharField(max_length=100)
    description = models.TextField(null=True, blank=True)

    def __str__(self):
        return self.name


class Match(models.Model):
    team = models.ForeignKey(Team, on_delete=models.CASCADE)
    game = models.ForeignKey(Game, on_delete=models.CASCADE)
    live_link = models.URLField(null=True, blank=True)
    started_at = models.DateTimeField()
    ended_at = models.DateTimeField()

    def __str__(self):
        return f"{self.team} - {self.game}"


class Result(models.Model):
    RANK_CHOICES = [
        ('1st', '1st Place'),
        ('2nd', '2nd Place'),
        ('3rd', '3rd Place'),
    ]
    match = models.ForeignKey(Match, on_delete=models.CASCADE, related_name="results")
    rank = models.CharField(max_length=10, choices=RANK_CHOICES)
    submitted_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return f"{self.match} - {self.rank}"


# 🔹 Dynamic field visibility controller
class FieldVisibility(models.Model):
    MODEL_CHOICES = [
        ('Team', 'Team'),
        ('Game', 'Game'),
        ('Match', 'Match'),
        ('Result', 'Result'),
    ]
    model_name = models.CharField(max_length=50, choices=MODEL_CHOICES)
    field_name = models.CharField(max_length=50)
    is_visible = models.BooleanField(default=True)

    class Meta:
        unique_together = ('model_name', 'field_name')

    def __str__(self):
        return f"{self.model_name}.{self.field_name} ({'Visible' if self.is_visible else 'Hidden'})"
