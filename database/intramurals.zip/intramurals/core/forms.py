from django import forms
from .models import Team, Game, Match, Result, FieldVisibility


def get_visible_fields(model_name):
    return [
        fv.field_name
        for fv in FieldVisibility.objects.filter(model_name=model_name, is_visible=True)
    ]


class TeamForm(forms.ModelForm):
    class Meta:
        model = Team
        fields = get_visible_fields("Team")


class GameForm(forms.ModelForm):
    class Meta:
        model = Game
        fields = get_visible_fields("Game")


class MatchForm(forms.ModelForm):
    class Meta:
        model = Match
        fields = get_visible_fields("Match")


class ResultForm(forms.ModelForm):
    class Meta:
        model = Result
        fields = get_visible_fields("Result")
