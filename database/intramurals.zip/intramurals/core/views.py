from django.shortcuts import render, redirect
from .forms import MatchForm

def create_match(request):
    if request.method == "POST":
        form = MatchForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("create_match")
    else:
        form = MatchForm()
    return render(request, "core/match_form.html", {"form": form})
